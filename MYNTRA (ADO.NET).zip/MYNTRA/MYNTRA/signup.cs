﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYNTRA.Models;

namespace MYNTRA
{
    public partial class signup : Form
    {
        string Email;
        credentialsloic c = new credentialsloic();
        public signup()
        {
            InitializeComponent();
        }
       
        public signup(string email)
        {
            InitializeComponent(); 
            Email = email;
        }

        private void signup_Load(object sender, EventArgs e)
        {
            emailtxt.Text = Email;
        }
        
        private void signbtn_Click(object sender, EventArgs e)
        {
            string email = emailtxt.Text;
            if (c.isNotVaild(email))
            {
                MessageBox.Show("Mail already exist.Try new mail or signin");
            }
            else
            {
                Customer cu = new Customer();
                cu.Email = emailtxt.Text;
                cu.Password = passwordtxt.Text;
                cu.FullName = fullnametxt.Text;
                cu.Phone = phonetxt.Text;
                cu.Address = addresstxt.Text;
                cu.SecurityAns = SecurityQuestiontxt.Text;
                c.insertRow(cu);
                Login l = new Login();
                l.Show();
                this.Hide();
            }
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            l.Show();
            this.Hide();
        }
    }
}
