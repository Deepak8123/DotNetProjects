﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MYNTRA.Models;
namespace MYNTRA
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string user = usernametxt.Text;
            signup s = new signup(user);
            s.Show();
            this.Hide();
        }
        credentialsloic c = new credentialsloic();
        private void Loginbtn_Click(object sender, EventArgs e)
        {
            string user = usernametxt.Text;
            string password = passwordtxt.Text;
            Customer cust = null; 
            int isvalid = c.isValidUser(user,password,out cust);
            if (isvalid == 0)
            {
                MessageBox.Show("You have To SIGNUP first");
                
            }
            else if (isvalid == 1)
            {
                MessageBox.Show("ReEnter the Password");
                passwordtxt.Text = "";
            }
            else if(isvalid==2)
            {
                MessageBox.Show("Login successFul");
                MessageBox.Show(cust.ToString());
            }
            else
            {
                MessageBox.Show("Error");
            }
        }

        private void linkLabel1_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            string email = usernametxt.Text;
            securityqsn sq = new securityqsn(email);
            sq.Show();
            this.Hide();
        }

    }
}
