﻿namespace EmployeeMGMT
{
    partial class UpDateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.lblupdateform = new System.Windows.Forms.Label();
            this.lblsearch = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.NumericUpDown();
            this.btnsearch = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblempname = new System.Windows.Forms.Label();
            this.lbldeptid = new System.Windows.Forms.Label();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.txtdeptid = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMPNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DEPTID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.txtempid)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblupdateform
            // 
            this.lblupdateform.AutoSize = true;
            this.lblupdateform.BackColor = System.Drawing.Color.Red;
            this.lblupdateform.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdateform.ForeColor = System.Drawing.Color.Transparent;
            this.lblupdateform.Location = new System.Drawing.Point(696, 25);
            this.lblupdateform.Name = "lblupdateform";
            this.lblupdateform.Size = new System.Drawing.Size(198, 29);
            this.lblupdateform.TabIndex = 1;
            this.lblupdateform.Text = "UPDATE FORM";
            // 
            // lblsearch
            // 
            this.lblsearch.AutoSize = true;
            this.lblsearch.BackColor = System.Drawing.Color.Red;
            this.lblsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsearch.ForeColor = System.Drawing.Color.Transparent;
            this.lblsearch.Location = new System.Drawing.Point(37, 129);
            this.lblsearch.Name = "lblsearch";
            this.lblsearch.Size = new System.Drawing.Size(188, 29);
            this.lblsearch.TabIndex = 2;
            this.lblsearch.Text = "ENTER EMPID";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(303, 136);
            this.txtempid.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(144, 22);
            this.txtempid.TabIndex = 3;
            // 
            // btnsearch
            // 
            this.btnsearch.BackColor = System.Drawing.Color.Red;
            this.btnsearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsearch.ForeColor = System.Drawing.Color.Transparent;
            this.btnsearch.Location = new System.Drawing.Point(511, 114);
            this.btnsearch.Name = "btnsearch";
            this.btnsearch.Size = new System.Drawing.Size(137, 58);
            this.btnsearch.TabIndex = 8;
            this.btnsearch.Text = "SEARCH";
            this.btnsearch.UseVisualStyleBackColor = false;
            this.btnsearch.Click += new System.EventHandler(this.btnsearch_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtdeptid);
            this.panel1.Controls.Add(this.txtempname);
            this.panel1.Controls.Add(this.lbldeptid);
            this.panel1.Controls.Add(this.lblempname);
            this.panel1.Location = new System.Drawing.Point(42, 200);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(438, 210);
            this.panel1.TabIndex = 9;
            // 
            // lblempname
            // 
            this.lblempname.AutoSize = true;
            this.lblempname.BackColor = System.Drawing.Color.Red;
            this.lblempname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblempname.ForeColor = System.Drawing.Color.Transparent;
            this.lblempname.Location = new System.Drawing.Point(16, 25);
            this.lblempname.Name = "lblempname";
            this.lblempname.Size = new System.Drawing.Size(106, 20);
            this.lblempname.TabIndex = 3;
            this.lblempname.Text = "EMP NAME";
            // 
            // lbldeptid
            // 
            this.lbldeptid.AutoSize = true;
            this.lbldeptid.BackColor = System.Drawing.Color.Red;
            this.lbldeptid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeptid.ForeColor = System.Drawing.Color.Transparent;
            this.lbldeptid.Location = new System.Drawing.Point(16, 93);
            this.lbldeptid.Name = "lbldeptid";
            this.lbldeptid.Size = new System.Drawing.Size(77, 20);
            this.lbldeptid.TabIndex = 4;
            this.lbldeptid.Text = "DEPTID";
            // 
            // txtempname
            // 
            this.txtempname.Location = new System.Drawing.Point(210, 25);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(210, 22);
            this.txtempname.TabIndex = 5;
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.Red;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.ForeColor = System.Drawing.Color.Transparent;
            this.btnupdate.Location = new System.Drawing.Point(113, 492);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(137, 58);
            this.btnupdate.TabIndex = 10;
            this.btnupdate.Text = "UPDATE";
            this.btnupdate.UseVisualStyleBackColor = false;
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Red;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Transparent;
            this.btnback.Location = new System.Drawing.Point(729, 492);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(137, 58);
            this.btnback.TabIndex = 12;
            this.btnback.Text = "BACK";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // txtdeptid
            // 
            this.txtdeptid.Location = new System.Drawing.Point(210, 91);
            this.txtdeptid.Name = "txtdeptid";
            this.txtdeptid.Size = new System.Drawing.Size(210, 22);
            this.txtdeptid.TabIndex = 6;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EMPID,
            this.EMPNAME,
            this.DEPTID});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(238)))), ((int)(((byte)(218)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(202)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(511, 190);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(426, 247);
            this.dataGridView1.TabIndex = 13;
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMPID";
            this.EMPID.HeaderText = "EMPID";
            this.EMPID.Name = "EMPID";
            this.EMPID.ReadOnly = true;
            // 
            // EMPNAME
            // 
            this.EMPNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMPNAME.DataPropertyName = "EMPNAME";
            this.EMPNAME.HeaderText = "EMPNAME";
            this.EMPNAME.Name = "EMPNAME";
            this.EMPNAME.ReadOnly = true;
            // 
            // DEPTID
            // 
            this.DEPTID.DataPropertyName = "DEPTID";
            this.DEPTID.HeaderText = "DEPTID";
            this.DEPTID.Name = "DEPTID";
            this.DEPTID.ReadOnly = true;
            // 
            // UpDateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(965, 626);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnupdate);
            this.Controls.Add(this.lblsearch);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnsearch);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.lblupdateform);
            this.Name = "UpDateForm";
            this.Text = "UpDateForm";
            this.Load += new System.EventHandler(this.UpDateForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtempid)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblupdateform;
        private System.Windows.Forms.Label lblsearch;
        private System.Windows.Forms.NumericUpDown txtempid;
        private System.Windows.Forms.Button btnsearch;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.Label lbldeptid;
        private System.Windows.Forms.Label lblempname;
        private System.Windows.Forms.Button btnupdate;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.TextBox txtdeptid;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEPTID;
    }
}