﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class specificdata : Form
    {
        EmployeeLogic ob = new EmployeeLogic();
        public specificdata()
        {
            InitializeComponent();
        }
        private void specificdata_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }
        public static void display(int id)
        {

        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtempid.Value.ToString());
            EMPLOYEE emp = ob.SearchData(id);
            if (emp == null)
            {
                MessageBox.Show("Employee with specific id not exist");
                dataGridView1.Visible = false;
            }
            else
            {
                using (EmpMGMTEntities db = new EmpMGMTEntities())
                {
                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.Visible = true;
                    dataGridView1.DataSource = db.specific_emprec(id);
                }
            }           
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
