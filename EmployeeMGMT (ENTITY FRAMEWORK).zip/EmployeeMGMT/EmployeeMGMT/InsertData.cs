﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class InsertData : Form
    {
        EmployeeLogic ob = new EmployeeLogic();
        public InsertData()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            EMPLOYEE emp = new EMPLOYEE();
            emp.EMPID = int.Parse(txtempid.Text);
            emp.EMPNAME = txtempname.Text;
            emp.DEPTID = int.Parse(txtdeptid.Text);

            ob.insert_empdata(emp);
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
