﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class UpDateForm : Form
    {
        EmployeeLogic ob = new EmployeeLogic();
        public UpDateForm()
        {
            InitializeComponent();
        }

        private void UpDateForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtempid.Value.ToString());
            EMPLOYEE emp = ob.SearchData(id);
            if(emp == null)
            {
                txtempname.Text = "";
                txtdeptid.Text = "";
                MessageBox.Show("Employee with specific id not exist");
            }
            else
            {
                panel1.Visible = true;
                txtempname.Text = emp.EMPNAME;
                txtdeptid.Text = emp.DEPTID.ToString();
                btnupdate.Visible = true;
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            EMPLOYEE emp = new EMPLOYEE();
            emp.EMPID = Convert.ToInt32(txtempid.Value);
            emp.EMPNAME = txtempname.Text.ToString();
            emp.DEPTID = Convert.ToInt32(txtdeptid.Text);
            dataGridView1.AutoGenerateColumns = false;
            using (EmpMGMTEntities db = new EmpMGMTEntities())
            {
                MessageBox.Show("Data updated successfully");
                db.specific_updateemprec(emp.EMPID,emp.EMPNAME, emp.DEPTID);
                db.SaveChanges();
                dataGridView1.DataSource = db.EMPLOYEEs.ToList<EMPLOYEE>();
            }
                  
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
