﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class DisplayData : Form
    {
        EmployeeLogic ob = new EmployeeLogic();
        public DisplayData()
        {
            InitializeComponent();
        }

        private void DisplayData_Load(object sender, EventArgs e)
        {
            dataGridView1.Visible = false;
        }

        private void btnshow_Click(object sender, EventArgs e)
        {
            dataGridView1.Visible = true;
            dataGridView1.AutoGenerateColumns = false;
            using (EmpMGMTEntities db = new EmpMGMTEntities())
            {
                dataGridView1.DataSource = db.EMPLOYEEs.ToList<EMPLOYEE>(); 
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
