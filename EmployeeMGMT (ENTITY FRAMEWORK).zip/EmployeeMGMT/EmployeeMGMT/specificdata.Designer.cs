﻿namespace EmployeeMGMT
{
    partial class specificdata
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.EMPID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMPNAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DEPTID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnshow = new System.Windows.Forms.Button();
            this.lbldisplayform = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.NumericUpDown();
            this.btnback = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtempid)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EMPID,
            this.EMPNAME,
            this.DEPTID});
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(209)))), ((int)(((byte)(238)))), ((int)(((byte)(218)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(123)))), ((int)(((byte)(202)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.Location = new System.Drawing.Point(109, 177);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowTemplate.Height = 30;
            this.dataGridView1.Size = new System.Drawing.Size(590, 247);
            this.dataGridView1.TabIndex = 3;
            // 
            // EMPID
            // 
            this.EMPID.DataPropertyName = "EMPID";
            this.EMPID.HeaderText = "EMPID";
            this.EMPID.Name = "EMPID";
            this.EMPID.ReadOnly = true;
            // 
            // EMPNAME
            // 
            this.EMPNAME.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.EMPNAME.DataPropertyName = "EMPNAME";
            this.EMPNAME.HeaderText = "EMPNAME";
            this.EMPNAME.Name = "EMPNAME";
            this.EMPNAME.ReadOnly = true;
            // 
            // DEPTID
            // 
            this.DEPTID.DataPropertyName = "DEPTID";
            this.DEPTID.HeaderText = "DEPTID";
            this.DEPTID.Name = "DEPTID";
            this.DEPTID.ReadOnly = true;
            // 
            // btnshow
            // 
            this.btnshow.BackColor = System.Drawing.Color.Red;
            this.btnshow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshow.ForeColor = System.Drawing.Color.Transparent;
            this.btnshow.Location = new System.Drawing.Point(519, 77);
            this.btnshow.Name = "btnshow";
            this.btnshow.Size = new System.Drawing.Size(137, 58);
            this.btnshow.TabIndex = 9;
            this.btnshow.Text = "SHOW";
            this.btnshow.UseVisualStyleBackColor = false;
            this.btnshow.Click += new System.EventHandler(this.btnshow_Click);
            // 
            // lbldisplayform
            // 
            this.lbldisplayform.AutoSize = true;
            this.lbldisplayform.BackColor = System.Drawing.Color.Red;
            this.lbldisplayform.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldisplayform.ForeColor = System.Drawing.Color.Transparent;
            this.lbldisplayform.Location = new System.Drawing.Point(104, 91);
            this.lbldisplayform.Name = "lbldisplayform";
            this.lbldisplayform.Size = new System.Drawing.Size(188, 29);
            this.lbldisplayform.TabIndex = 10;
            this.lbldisplayform.Text = "ENTER EMPID";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(338, 99);
            this.txtempid.Maximum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(144, 22);
            this.txtempid.TabIndex = 11;
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Red;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Transparent;
            this.btnback.Location = new System.Drawing.Point(758, 448);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(137, 58);
            this.btnback.TabIndex = 12;
            this.btnback.Text = "BACK";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(503, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(399, 29);
            this.label1.TabIndex = 13;
            this.label1.Text = "SPECIFIC DATA DISPLAY FORM";
            // 
            // specificdata
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(940, 537);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.lbldisplayform);
            this.Controls.Add(this.btnshow);
            this.Controls.Add(this.dataGridView1);
            this.Name = "specificdata";
            this.Text = "specificdata";
            this.Load += new System.EventHandler(this.specificdata_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtempid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPID;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMPNAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn DEPTID;
        private System.Windows.Forms.Button btnshow;
        private System.Windows.Forms.Label lbldisplayform;
        private System.Windows.Forms.NumericUpDown txtempid;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Label label1;
    }
}