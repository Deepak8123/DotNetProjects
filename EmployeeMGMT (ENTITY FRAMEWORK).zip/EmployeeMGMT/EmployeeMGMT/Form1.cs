﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            EmpMGMTEntities db = new EmpMGMTEntities();
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            InsertData ob = new InsertData();
            ob.Show();
            this.Hide();
        }

        private void btndetails_Click(object sender, EventArgs e)
        {
            DisplayData ob = new DisplayData();
            ob.Show();
            this.Hide();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            UpDateForm ob = new UpDateForm();
            ob.Show();
            this.Hide();
        }

        private void btnfind_Click(object sender, EventArgs e)
        {
            specificdata ob = new specificdata();
            ob.Show();
            this.Hide();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            DeleteData ob = new DeleteData();
            this.Hide();
            ob.Show();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sccessfully loged out");
            Application.Exit();
        }
    }
}
