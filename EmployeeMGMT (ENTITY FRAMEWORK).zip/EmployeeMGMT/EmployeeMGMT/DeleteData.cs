﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    public partial class DeleteData : Form
    {
        EmpMGMTEntities db = new EmpMGMTEntities();
        EmployeeLogic ob = new EmployeeLogic();
        public DeleteData()
        {
            InitializeComponent();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtempid.Value.ToString());
            EMPLOYEE emp = db.EMPLOYEEs.Find(id);
            if (emp == null)
            {
                txtempid.Text = "";
                MessageBox.Show("Employee with specific id not exist");
            }
            else
            {              
                dataGridView1.AutoGenerateColumns = false;
                db.EMPLOYEEs.Remove(emp);
                db.SaveChanges();
                MessageBox.Show("Deleted Successfully");
                dataGridView1.DataSource = db.EMPLOYEEs.ToList<EMPLOYEE>();
            }
        }

        private void btnback_Click(object sender, EventArgs e)
        {
            Form1 ob = new Form1();
            ob.Show();
            this.Hide();
        }
    }
}
