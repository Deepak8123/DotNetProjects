﻿namespace EmployeeMGMT
{
    partial class InsertData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblinsertform = new System.Windows.Forms.Label();
            this.lblempid = new System.Windows.Forms.Label();
            this.lblempname = new System.Windows.Forms.Label();
            this.lbldeptid = new System.Windows.Forms.Label();
            this.txtempid = new System.Windows.Forms.TextBox();
            this.txtempname = new System.Windows.Forms.TextBox();
            this.txtdeptid = new System.Windows.Forms.TextBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.btnback = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblinsertform
            // 
            this.lblinsertform.AutoSize = true;
            this.lblinsertform.BackColor = System.Drawing.Color.Red;
            this.lblinsertform.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinsertform.ForeColor = System.Drawing.Color.Transparent;
            this.lblinsertform.Location = new System.Drawing.Point(619, 43);
            this.lblinsertform.Name = "lblinsertform";
            this.lblinsertform.Size = new System.Drawing.Size(190, 29);
            this.lblinsertform.TabIndex = 0;
            this.lblinsertform.Text = "INSERT FORM";
            // 
            // lblempid
            // 
            this.lblempid.AutoSize = true;
            this.lblempid.BackColor = System.Drawing.Color.Red;
            this.lblempid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblempid.ForeColor = System.Drawing.Color.Transparent;
            this.lblempid.Location = new System.Drawing.Point(47, 154);
            this.lblempid.Name = "lblempid";
            this.lblempid.Size = new System.Drawing.Size(93, 29);
            this.lblempid.TabIndex = 1;
            this.lblempid.Text = "EMPID";
            // 
            // lblempname
            // 
            this.lblempname.AutoSize = true;
            this.lblempname.BackColor = System.Drawing.Color.Red;
            this.lblempname.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblempname.ForeColor = System.Drawing.Color.Transparent;
            this.lblempname.Location = new System.Drawing.Point(47, 226);
            this.lblempname.Name = "lblempname";
            this.lblempname.Size = new System.Drawing.Size(141, 29);
            this.lblempname.TabIndex = 2;
            this.lblempname.Text = "EMPNAME";
            // 
            // lbldeptid
            // 
            this.lbldeptid.AutoSize = true;
            this.lbldeptid.BackColor = System.Drawing.Color.Red;
            this.lbldeptid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeptid.ForeColor = System.Drawing.Color.Transparent;
            this.lbldeptid.Location = new System.Drawing.Point(47, 296);
            this.lbldeptid.Name = "lbldeptid";
            this.lbldeptid.Size = new System.Drawing.Size(107, 29);
            this.lbldeptid.TabIndex = 3;
            this.lbldeptid.Text = "DEPTID";
            // 
            // txtempid
            // 
            this.txtempid.Location = new System.Drawing.Point(300, 154);
            this.txtempid.Name = "txtempid";
            this.txtempid.Size = new System.Drawing.Size(184, 22);
            this.txtempid.TabIndex = 4;
            // 
            // txtempname
            // 
            this.txtempname.Location = new System.Drawing.Point(300, 233);
            this.txtempname.Name = "txtempname";
            this.txtempname.Size = new System.Drawing.Size(184, 22);
            this.txtempname.TabIndex = 5;
            // 
            // txtdeptid
            // 
            this.txtdeptid.Location = new System.Drawing.Point(300, 296);
            this.txtdeptid.Name = "txtdeptid";
            this.txtdeptid.Size = new System.Drawing.Size(184, 22);
            this.txtdeptid.TabIndex = 6;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.Red;
            this.btnsubmit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsubmit.ForeColor = System.Drawing.Color.Transparent;
            this.btnsubmit.Location = new System.Drawing.Point(105, 416);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(137, 58);
            this.btnsubmit.TabIndex = 7;
            this.btnsubmit.Text = "INSERT";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.Color.Red;
            this.btnback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnback.ForeColor = System.Drawing.Color.Transparent;
            this.btnback.Location = new System.Drawing.Point(347, 416);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(137, 58);
            this.btnback.TabIndex = 8;
            this.btnback.Text = "BACK";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.btnback_Click);
            // 
            // InsertData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Yellow;
            this.ClientSize = new System.Drawing.Size(886, 506);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txtdeptid);
            this.Controls.Add(this.txtempname);
            this.Controls.Add(this.txtempid);
            this.Controls.Add(this.lbldeptid);
            this.Controls.Add(this.lblempname);
            this.Controls.Add(this.lblempid);
            this.Controls.Add(this.lblinsertform);
            this.Name = "InsertData";
            this.Text = "InsertData";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblinsertform;
        private System.Windows.Forms.Label lblempid;
        private System.Windows.Forms.Label lblempname;
        private System.Windows.Forms.Label lbldeptid;
        private System.Windows.Forms.TextBox txtempid;
        private System.Windows.Forms.TextBox txtempname;
        private System.Windows.Forms.TextBox txtdeptid;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.Button btnback;
    }
}