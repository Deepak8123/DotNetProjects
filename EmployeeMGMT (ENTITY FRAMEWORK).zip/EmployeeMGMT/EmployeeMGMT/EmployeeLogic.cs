﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeMGMT
{
    class EmployeeLogic
    {
        EmpMGMTEntities db = new EmpMGMTEntities();

        public void insert_empdata(EMPLOYEE emp)
        {
            MessageBox.Show("Inserted sccessfully");
            db.EMPLOYEEs.Add(emp);
            db.SaveChanges();
        }
        
        public EMPLOYEE SearchData(int id)
        {
            EMPLOYEE e= db.EMPLOYEEs.Find(id);
            if(e==null)
            {        
                return null;
            }
            else
            {
                return e;
            }          
        }
    }
}
