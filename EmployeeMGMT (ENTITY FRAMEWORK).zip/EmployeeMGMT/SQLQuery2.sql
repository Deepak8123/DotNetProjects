﻿create   procedure specific_emprec
@empid int
as
select * from EMPLOYEE where EMPID = @empid