﻿create   procedure specific_updateemprec
@empid int,
@empname varchar,
@deptid int
as
update EMPLOYEE set EMPNAME=@empname, DEPTID=@deptid where EMPID=@empid