﻿set ansi_nulls on
go
set quoted_identifier on
go
create or alter procedure displayall_emprec
as
select * from EMPLOYEE