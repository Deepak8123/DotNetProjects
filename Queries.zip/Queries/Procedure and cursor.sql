﻿create procedure stpr_SpecificEmpRec1
	@eid int,
	@ENAME VARCHAR(50) OUTPUT,
	@SAL FLOAT OUTPUT
as
begin
select @ENAME=EmpName, @SAL = Salary
from EmployeeDetails where Id = @eid
end

BEGIN
	DECLARE @ENAME VARCHAR(50)
	DECLARE @SAL FLOAT
	EXEC stpr_SpecificEmpRec1 111, @ENAME OUTPUT, @SAL OUTPUT

	PRINT 'NAME = ' +@ENAME +' HAS SAL = ' +CAST(@SAL AS VARCHAR(50))

	END

	SELECT * FROM EmployeeDetails

	-------CURSOR------------

	create procedure stpr_InsertEmpRec
	@ID INT,
	@ENAME VARCHAR(50),
	@SAL FLOAT,
	@MGRID INT,
	@DEPTID INT
	as
	begin
	INSERT INTO EmployeeDetails VALUES (@ID,@ENAME,@SAL,@MGRID,@DEPTID)
		
	end

	exec stpr_InsertEmpRec 666, 'Rohit',5000,222,22

	exec stpr_SpecificEmpRec1







