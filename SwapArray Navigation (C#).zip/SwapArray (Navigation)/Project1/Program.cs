﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project1
{
    class swapArray
    {
        static int[] arr = new int[1000];
        static int loc, ch, size, mat_size;
        static int left_bound, right_bound;

        static void disp()
        {
            Console.WriteLine("\n");
            for (int i = 0; i < mat_size; i++)
            {
                Console.Write(arr[i] + " ");
                if (((i + 1) % size) == 0)
                    Console.WriteLine("\n");
            }
        }

        static void Main(string[] args)
        {
            Console.Write("Size of matrix will be n*n. So, Enter value for n : ");
            size = Convert.ToInt32(Console.ReadLine());

            mat_size = size * size;

            for (int i = 0; i < mat_size; i++)
                arr[i] = 0;

            disp();

            Console.WriteLine("Enter start location : ");
            loc = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Entered location: " + loc + "\n\n");

            while (true)
            {
                Console.Write("Enter your choice : ");
                Console.WriteLine("Enter the choice between 2 or 4 or 6 or 8");
                Console.WriteLine("2 is for Down");
                Console.WriteLine("4 is for Left");
                Console.WriteLine("6 is for Right");
                Console.WriteLine("8 is for Up");
                Console.WriteLine("5 is for successfully log out from program");
                ch = Convert.ToInt32(Console.ReadLine());

                if (ch == 8)
                {
                    loc = loc - size;
                    if (loc >= 0)
                    {
                        loc = loc + size;
                        arr[loc] = 0;
                        loc = loc - size;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc = loc + size;
                        Console.Write("out of boundary....Enter correct choice: ");
                    }
                }
                else if (ch == 4)
                {
                    for (int i = 0; i <= (mat_size - size); i = i + size)
                    {
                        int j = (i + size) - 1;
                        if (loc >= i && loc <= j)
                        {
                            left_bound = i;
                            //	right_bound=j;
                            break;
                        }
                    }

                    loc--;
                    if (loc >= left_bound)
                    {
                        loc++;
                        arr[loc] = 0;
                        loc--;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc++;
                        Console.Write("out of boundary....Enter correct choice: ");
                    }
                }
                else if (ch == 6)
                {
                    for (int i = 0; i <= (mat_size - size); i = i + size)
                    {
                        int j = i + size - 1;
                        if (loc >= i && loc <= j)
                        {
                            //	left_bound=i;
                            right_bound = j;
                            break;
                        }
                    }

                    loc++;
                    if (loc <= right_bound)
                    {
                        loc--;
                        arr[loc] = 0;
                        loc++;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc--;
                        Console.Write("out of boundary....Enter correct choice: ");
                    }
                }
                else if (ch == 2)
                {
                    loc = loc + size;
                    if (loc < mat_size)
                    {
                        loc = loc - size;
                        arr[loc] = 0;
                        loc = loc + size;
                        arr[loc] = 1;
                    }
                    else
                    {
                        loc = loc - size;
                        Console.Write("out of boundary....Enter correct choice: ");
                    }
                }
                else if (ch == 5)
                {
                    break;
                }
                else
                {
                    Console.Write("You have entered wrong choice...");
                }
                disp();
            }
        }
    }
}
    
