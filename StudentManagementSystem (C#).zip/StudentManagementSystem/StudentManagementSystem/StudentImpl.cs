﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    class StudentImpl
    {
        static void Main(string[] args)
        {
            int i,n, ch;
            string UserName;
            long Password;
            Console.WriteLine("LOGIN");
            Console.WriteLine("Enter User Name: ");
            UserName = Console.ReadLine();
            Console.WriteLine("Enter Password: ");
            Password = long.Parse(Console.ReadLine());



            if (UserName == "Admin" && Password == 123456)
            {
                Console.WriteLine("\nLOGGED IN SUCCESSFULLY");
                Console.WriteLine("Enter the number of student record");
                n = int.Parse(Console.ReadLine());
                Student[] s1 = new Student[n];
                for (i = 0; i < n; i++)
                {
                    s1[i] = new Student();
                    do
                    {
                        Console.WriteLine("-------------------------------------------------");
                        Console.WriteLine("Press 1 to insert new student details ");
                        Console.WriteLine("Press 2 to calculate marks details ");
                        Console.WriteLine("Press 3 to show new student details ");
                        Console.WriteLine("Press 4 Exit ");
                        Console.WriteLine("-------------------------------------------------");

                        ch = int.Parse(Console.ReadLine());

                        switch (ch)
                        {
                            case 1:
                                s1[0].GetNewStudent(); break;
                            case 2:
                                s1[0].Calculate(); break;
                            case 3:
                                s1[0].ShowStdDetails(); break;
                            case 4: break;
                        }
                    } while (ch != 4);
                }
            }
            else
                Console.WriteLine("Incorrect user name or password ");
            }
        }
}

