﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagementSystem
{
    class Student
    {
        public int StdId, NoOfSub;
        public string StdName, Grade;
        public float[] marks;
        public float total, avg;

        public void GetNewStudent()
        {
            Console.WriteLine("Enter the student ID: ");
            StdId = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the student Name: ");
            StdName = Console.ReadLine();
            Console.WriteLine("Enter the student Number of subjects: ");
            NoOfSub = int.Parse(Console.ReadLine());
            marks = new float[NoOfSub];
            Console.WriteLine("Enter the student Marks: ");
            for(int i=0;i<NoOfSub;i++)
            {
                marks[i] = float.Parse(Console.ReadLine());
                total = 0;
            }
        }

        public void Calculate()
        {
            for (int i = 0; i < NoOfSub; i++)
            {
                total +=marks[i];
            }
            avg = total / NoOfSub;
            if (avg >= 60 && avg <= 100)
            {
                Grade = "FIRST CLASS";
            }
            else if(avg>=35 && avg<=59)
            {
                Grade = "SECOND CLASS";
            }
            else 
            {
                Grade = "FAILED";
            }
        }

        public void ShowStdDetails()
        {
            Console.WriteLine("-----------------Student Details------------------------");
            Console.WriteLine("Student ID:             " + StdId);
            Console.WriteLine("Student Name:           " + StdName);
            Console.WriteLine("Number of subjects:     " + NoOfSub);
           for(int i=0;i<marks.Count();i++)
            {
                Console.WriteLine("Marks"+i+":                 "+marks[i] + "\t");
            }
            Console.WriteLine("TOTAL MARKS:            " + total);
            Console.WriteLine("Student Average:        " + avg);
            Console.WriteLine("Grade:                  " + Grade);
        }
    }
}
